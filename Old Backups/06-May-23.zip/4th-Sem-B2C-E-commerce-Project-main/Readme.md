The Group consists of Members:

    2021327 Ahabb Sheraz
  
    2021510 Nauman Asif
  
    2021609 Sohaib Nasir

The general purpose of this project is to make a web application with proper functioning frontend and backend (a database providing all the necessary tables and data) for a General Purpose E-commerce website based on the concept of B2C (Business to Consumer).

